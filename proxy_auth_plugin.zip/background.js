
    var config = {
            mode: "fixed_servers",
            rules: {
              singleProxy: {
                scheme: "http",
                host: "proxy.scraperapi.com",
                port: parseInt(8001)
              },
              bypassList: ["localhost"]
            }
          };
    chrome.proxy.settings.set({value: config, scope: "regular"}, function() {});

    chrome.webRequest.onAuthRequired.addListener(
        function(details) {
            return {
                authCredentials: {
                    username: "scraperapi",
                    password: "your_scraperapi_key"
                }
            };
        },
        {urls: ["<all_urls>"]},
        ['blocking']
    );
    